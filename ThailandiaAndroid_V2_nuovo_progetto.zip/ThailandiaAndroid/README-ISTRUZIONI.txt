THAILANDIA 2026 – NUOVO PROGETTO (VERSIONE 2.0)

Questo progetto è indipendente dalla prima app: usa un applicationId diverso, quindi può essere installato insieme alla versione precedente.

Novità:
- grafica rinnovata in stile travel journal;
- sezione La mia mappa con i tre alloggi già inseriti;
- MBK Center aggiunto al primo giorno e come destinazione iniziale;
- aggiunta di luoghi personalizzati;
- selezione alloggio/destinazione e apertura del percorso in Google Maps;
- itinerario, checklist, diario, documenti e backup.

La lista dei luoghi è memorizzata localmente. Google Maps richiede internet per calcolare distanze e tempi.

Compilazione cloud: caricare il contenuto dello ZIP nel repository di un progetto separato oppure sostituire lo ZIP nel repository GitHub già usato. Il workflow estrae il progetto e compila app/build/outputs/apk/debug/app-debug.apk.

Package ID: it.thailandia.viaggio.v2
Versione: 2.0
